<?php

namespace frontend\modules\practice;

use Yii;

class Practice extends \yii\base\Module
{
	public $controllerNamespace = 'frontend\modules\practice\controllers';

	public $defaultRoute = 'site'; 

	public function init()
	{
	   // die("die...sdfsad");
	   parent::init();
	}
}
