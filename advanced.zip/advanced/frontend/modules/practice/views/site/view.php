<?php

use yii\grid\GridView;
use yii\helpers\Html;
use yii\bootstrap\Modal;
use frontend\modules\practice\component\Price;
use yii\widgets\Pjax;


// use yii\grid\ActionColumn;

$this->registerJsFile("@web/js/main.js", ['depends' => [\yii\web\JqueryAsset::className()]]);

?>

<div class="container">
   <?php  Pjax::begin(); ?>

    <?= Html::beginForm(['site/bulk'], 'post'); ?>
    <?= Html::submitButton('Export', ['class' => 'btn btn-success',]); ?>
    <?php
    echo GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            [
                'class' => 'yii\grid\CheckboxColumn',
                'checkboxOptions' => function ($dataProvider, $key, $index, $column) {
                    return ['value' => $dataProvider->id];
                },
                // 'content'=>function ($dataProvider, $key, $index, $column) {
                //     return ['value' => $dataProvider->index];
                // }
            ],
           
            [
                'class' => 'yii\grid\SerialColumn',
                'header' => 'Sr.No'
            ],
            'id',
            'product_id',
            [
                'attribute' => 'title',
                'value' => 'product.title'
            ],

            'variant_id',
            // 'price',
            [
                'attribute' => 'price',
                'filter' => $this->render('form', ['model' => $searchModel]),
                'value' => function ($model) {
                    return Price::range($model->product_id);
                }

            ],
            'inventory',
            [
                'class' => 'yii\grid\ActionColumn',
                'header' => 'Action',
                'template' => '{update}{delete}',
            ],

        ],
    ]);
    ?>
    <?= Html::endForm(); ?>
    <?php Pjax::end(); ?>
</div>
<button type="button" id="b1" class="btn btn-info" data-toggle="modal" data-target="#modal">Open Modal</button>

<?php
Modal::begin([
    'header' => 'Test',
    'id' => 'modal',
    'size' => 'modal-lg',
    'footer' => Html::a('Delete', ['site/delete'], ['class' => 'btn btn-danger']),
]);
echo "<div id='modalContent'>sqwddw</div>";
Modal::end();
?>