<footer class="footer fixed-bottom">
    <div class="container">
        <p class="pull-left">&copy; <?= "Practice Module"; ?> <?= date('Y') ?></p>

        <p class="pull-right"><?= Yii::powered() ?></p>
    </div>
</footer>