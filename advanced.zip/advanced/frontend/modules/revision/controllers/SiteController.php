<?php 

namespace frontend\modules\revision\controllers;

use yii\web\Controller;

class SiteController extends Controller
{
	public function actionIndex()
	{
		die("die..test");
	}
}