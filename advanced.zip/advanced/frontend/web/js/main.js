$(document).ready(function(){
    var data;
    var selectedItems = [];

       $('#b1').click(function (){
           selectedItems = selectedItems.concat($('.grid-view').yiiGridView('getSelectedRows'));
           // select all rows on page 1, go to page 2 and select all rows.
           // All rows on page 1 and 2 will be selected.
           console.log(selectedItems); 
       })
    //    var uniqueNames = [];
    //    $.each(selectedItems, function(i, el){
    //     if($.inArray(el, uniqueNames) === -1) uniqueNames.push(el);
    // });
    // console.log(uniqueNames);
    // $("#b1").click(function(){
    //    var a=$('.select-on-check-all').val();
    //    var keys = $('.grid-view').yiiGridView('getSelectedRows');
       
    //    console.log(a);
    //    console.log(  $( "input[name='selection[]']" ));
    //    console.log(keys);
    // })
    // $(".select-on-check-all").click(function(){
    //     console.log("all data");
    //    data="hello";
    // })

    // $.ajax({
    //     url:"site/bulk",
    //     method:"post",
    //     data:{

    //     }
    // })
})