function myFun(){
    let fname=document.getElementById('fname').value;
    let lname=document.getElementById('lname').value;
    alert("hello  "+fname+"  "+lname);
}