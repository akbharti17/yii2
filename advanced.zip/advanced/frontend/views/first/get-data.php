<?php
$data = json_decode($_POST['data']);
print_r($data);


// echo $data->name;
// echo $data->email;