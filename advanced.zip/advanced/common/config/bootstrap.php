<?php
Yii::setAlias('@common', dirname(__DIR__));
Yii::setAlias('@frontend', dirname(dirname(__DIR__)) . '/frontend');
Yii::setAlias('@backend', dirname(dirname(__DIR__)) . '/backend');
Yii::setAlias('@console', dirname(dirname(__DIR__)) . '/console');
Yii::setAlias('@homeroot', '/opt/lampp/htdocs/Training/advanced/uploads');
Yii::setAlias('@home', 'Training/advanced');
Yii::setAlias('@mdpracticecsv','/opt/lampp/htdocs/Training/advanced/frontend/modules/practice/csvfile');
Yii::setAlias('@asset','/opt/lampp/htdocs/Training/advanced/frontend/modules/practice/assets');
